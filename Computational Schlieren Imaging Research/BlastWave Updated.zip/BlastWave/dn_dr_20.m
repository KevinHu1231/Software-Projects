function [dn_dr] = dn_dr_20(r)
    dn_dr = 7.011e-7*r^2 - 6.898e-6*r + 2.104e-5;
end