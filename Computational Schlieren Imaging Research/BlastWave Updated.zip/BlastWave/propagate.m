function [new_x,new_v] = propagate(num,d,n_i,n_f,f,x_bound,v_bound,z_final)
theta = asin(v_bound(2));
phi = atan(v_bound(1)/v_bound(3));
if num == 1
    matrix = [1 d 0 0;0 1 0 0;0 0 1 d;0 0 0 1];
    d_z = d;
elseif num == 2
    matrix = [1 0 0 0;0 n_i/n_f 0 0;0 0 1 0;0 0 0 n_i/n_f];
    d_z = 0;
else
    matrix = [1 0 0 0;0 1 0 0;-1/f 0 1 0;0 0 -1/f 1];
    d_z = 0;
end
input = [x_bound(1); phi; x_bound(2); theta];
output = matrix * input;
new_x = [output(1), output(3), z_final];
new_v = [sin(output(2))*cos(output(4)),sin(output(4)),cos(output(2))*cos(output(4))];
end