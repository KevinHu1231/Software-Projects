function [ansr] = R_0(t)

    if t>(5e-6)
        ansr = 140.692 * t^0.893 + (2.466e-3);
        y = 0
    else
        ansr = 0.6680492345 * t^0.4;
        z = 1
        
end