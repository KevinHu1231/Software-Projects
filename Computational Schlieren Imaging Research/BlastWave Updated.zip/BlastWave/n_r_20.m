function [n] = n_r_20(r)
    n = 2.337e-7*r^3 - 3.449e-6*r^2 + 2.164e-5*r + 1 + 1.8e-4;
end