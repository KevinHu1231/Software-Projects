load t_10_data
load t_20_data
E = 1.38;
p_o = 101.325;%assume atmospheric pressure
R_star = (E/p_o)^(1/3);

plot(t10_data(:,1)*R_star/116.5,t10_data(:,2)) %R = r/R*
%r = R*R*
%r/R_0 = R*R*/R_0
hold on
plot(t20_data(:,1)*R_star/202,t20_data(:,2))
hold on