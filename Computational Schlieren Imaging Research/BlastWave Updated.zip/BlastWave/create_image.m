A = rand(512,512);
imwrite(A,'myimage.png') ; 
figure
imshow(A)
figure
imshow(imread('myimage.png'))