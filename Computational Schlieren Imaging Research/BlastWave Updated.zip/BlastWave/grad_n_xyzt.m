function [grad_n] = grad_n_xyzt(t,x,y,z)
    
    R0_t10 = 7.47;
    R0_t20 = 11.565;
    R0_t30 = 15.345;
    R0_t40 = 19.08;
    
    R0_t10_ts = 11.4;
    R0_t20_ts = 19.95;
    
    R_vac_ts10 = 5.4993;
    R_vac_ts20 = 7.1529;
    
    r = sqrt(x^2+y^2+z^2);
    
    if t==10
        R_0 = R0_t10;
        R_vac = -1;
    elseif t==20
        R_0 = R0_t20;
        R_vac = -1;
    elseif t==30
        R_0 = R0_t30;
        R_vac = -1;
    elseif t==40
        R_0 = R0_t40;
        R_vac = -1;
    elseif t==101
        R_0 = R0_t10_ts;
        R_vac = R_vac_ts10;
    elseif t==201
        R_0 = R0_t20_ts;
        R_vac = R_vac_ts20;
    else
        grad_n = [0 0 0];
    end
    
    if r>=R_0
        grad_n = [0 0 0];
    elseif r<=R_vac
        grad_n = [0 0 0];
    else
        if t==10
            dn_dr = dn_dr_10(r);
            grad_n = [x*(x^2+y^2+z^2)^(-1/2)*dn_dr, y*(x^2+y^2+z^2)^(-1/2)*dn_dr, z*(x^2+y^2+z^2)^(-1/2)*dn_dr];
        elseif t==20
            dn_dr = dn_dr_20(r);
            grad_n = [x*(x^2+y^2+z^2)^(-1/2)*dn_dr, y*(x^2+y^2+z^2)^(-1/2)*dn_dr, z*(x^2+y^2+z^2)^(-1/2)*dn_dr];
        elseif t==30
            dn_dr = dn_dr_30(r);
            grad_n = [x*(x^2+y^2+z^2)^(-1/2)*dn_dr, y*(x^2+y^2+z^2)^(-1/2)*dn_dr, z*(x^2+y^2+z^2)^(-1/2)*dn_dr];
        elseif t==40
            dn_dr = dn_dr_40(r);
            grad_n = [x*(x^2+y^2+z^2)^(-1/2)*dn_dr, y*(x^2+y^2+z^2)^(-1/2)*dn_dr, z*(x^2+y^2+z^2)^(-1/2)*dn_dr];
        elseif t==101
            dn_dr = dn_dr_ts10(r);
            grad_n = [x*(x^2+y^2+z^2)^(-1/2)*dn_dr, y*(x^2+y^2+z^2)^(-1/2)*dn_dr, z*(x^2+y^2+z^2)^(-1/2)*dn_dr];
        elseif t==201
            dn_dr = dn_dr_ts20(r);
            grad_n = [x*(x^2+y^2+z^2)^(-1/2)*dn_dr, y*(x^2+y^2+z^2)^(-1/2)*dn_dr, z*(x^2+y^2+z^2)^(-1/2)*dn_dr];
        else
            grad_n = [0 0 0];
        end
        
    end