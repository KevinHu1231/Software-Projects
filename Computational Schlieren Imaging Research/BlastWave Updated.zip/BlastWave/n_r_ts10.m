function [n] = n_r_ts10(r)
    n = 1.148e-5*r^2 - 9.35e-5*r + 1 + 1.7e-4;
end