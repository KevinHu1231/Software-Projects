function [n_r] = n_r_cyl(r_data,n_data,x,y,z)
    r = sqrt(x^2+y^2);
    if r<r_data(1)
        r2 = r_data(2);
        r1 = r_data(1);
        n2 = n_data(2);
        n1 = n_data(1);
    elseif r>r_data(length(r_data))
        r2 = r_data(length(r_data));
        r1 = r_data(length(r_data)-1);
        n2 = n_data(length(n_data));
        n1 = n_data(length(n_data)-1);
    else
        for i = 1:length(r_data)
            if r_data(i)>=r
                r2 = r_data(i);
                r1 = r_data(i-1);
                n2 = n_data(i);
                n1 = n_data(i-1);
                break
            end
        end
    end
    n_r = n1 + (r - r1)*(n2-n1)/(r2-r1);
end