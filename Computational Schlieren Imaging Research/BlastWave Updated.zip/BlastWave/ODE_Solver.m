%syms p(e) s(e) f(e) gamma
%eqns = [diff(p,e)*(e - p) == (1/g)*(diff(f,e)/s)-(3*p/2), diff(s,e)/s == (diff(p,e)+(2*p/e))/(e-p), 0 == 3*f+e*diff(f,e) + g*diff(s,e)*f*(p-e)/s - p*diff(f,e)];
%eqns = [diff(p) == ((-3*f)/(g*s*(e-p)) + (2*p*f/e)/(s*(e-p)) - (3*p/2))/((s*(e-p)^2-1)/(e-p)), diff(s) == (-3*f/(g*s*(p-e)^2)-3*p/(2*(e-p))+2*p/(e*(e-p))) / (1/s - f/(s^2*(e-p))), diff(f) == (-3*f - 3*g*p*f/(2*(e-p)) + (2*p*f/e))/(e - f/(s*(e-p))-p)]
%[x,y,z] = dsolve('Dp == ((-3*f)/(g*s*(e-p)) + (2*p*f/e)/(s*(e-p)) - (3*p/2))/((s*(e-p)^2-1)/(e-p))', 'Ds == (-3*f/(g*s*(p-e)^2)-3*p/(2*(e-p))+2*p/(e*(e-p))) / (1/s - f/(s^2*(e-p)))', 'Df == (-3*f - 3*g*p*f/(2*(e-p)) + (2*p*f/e))/(e - f/(s*(e-p))-p)')
%[x,y,z] = dsolve('Dp*(e - p) == (1/gamma)*(Df/s)-(3*p/2)', 'Ds/s == (Dp+(2*p/e))/(e-p)', '3*f+e*Df + gamma*Ds*f*(p-e)/s - p*Df == 0','Implicit',true);
%function dydt = ODE_Solver(e,y)
 %   dydt = [((-3*y(3))/(1*y(2)*(e-y(1))) + (2*y(1)*y(3)/e)/(y(2)*(e-y(1))) - (3*y(1)/2))/((y(2)*(e-y(1))^2-1)/(e-y(1)))
  %          (-3*y(3)/(1*y(2)*(y(1)-e)^2) - 3*y(1)/(2*(e-y(1))) + 2*y(1)/(e*(e-y(1)))) / (1/y(2) - y(3)/(y(2)^2*(e-y(1))))
   %         (-3*y(3) - 3*1*y(1)*y(3)/(2*(e-y(1))) + (2*y(1)*y(3)/e))/(e - y(3)/(y(2)*(e-y(1)))-y(1))];
%end

function dydt = ODE_Solver(e,y)
    dydt = zeros(3,1); % this creates an empty column
    %vector that you can fill with your two derivatives:
    dydt(1) = ((-3*y(3))/(1*y(2)*(e-y(1))) + (2*y(1)*y(3)/e)/(y(2)*(e-y(1))) - (3*y(1)/2))/((y(2)*(e-y(1))^2-1)/(e-y(1)));
    dydt(2) = (-3*y(3)/(1*y(2)*(y(1)-e)^2) - 3*y(1)/(2*(e-y(1))) + 2*y(1)/(e*(e-y(1)))) / (1/y(2) - y(3)/(y(2)^2*(e-y(1))));
    dydt(3) = (-3*y(3) - 3*1*y(1)*y(3)/(2*(e-y(1))) + (2*y(1)*y(3)/e))/(e - y(3)/(y(2)*(e-y(1)))-y(1));
    %In this case, y(1) is y1 and y(2) is y2, and dydt(1)
    %is dy1/dt and dydt(2) is dy2/dt.
end
%p = y(1)
%s = y(2)
%f = y(3)