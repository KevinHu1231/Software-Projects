load cyl_d_1
load cyl_d_2
load cyl_d_3
load cyl_d_4
load cyl_d_5
load cyl_d_6
load cyl_d_7
load cyl_d_8

E_0 = 1;
gamma = 1.4;
b = 3.94;
p_0 = 101325;
a_0 = 344;
R_0 = sqrt(4*E_0/(b*gamma*p_0));
rho_0 = 1.2754;

t_1 = 0.0000777*R_0/a_0;
t_2 = 0.00213*R_0/a_0;
t_3 = 0.00927*R_0/a_0;
t_4 = 0.0559*R_0/a_0;
t_5 = 0.188*R_0/a_0;
t_6 = 0.544*R_0/a_0;
t_7 = 1.83*R_0/a_0;
t_8 = 4.15*R_0/a_0;

Ka = (0.226 * 1000/1000000);

x1 = R_0.*cyl_d_1(:,1); %R = 1.5e-4
y1 = (rho_0*Ka).*cyl_d_1(:,2) + 1;
x2 = R_0.*cyl_d_2(:,1); %R = 3.0e-4
y2 = (rho_0*Ka).*cyl_d_2(:,2) + 1;
x3 = R_0.*cyl_d_3(:,1); %R = 7.0e-4
y3 = (rho_0*Ka).*cyl_d_3(:,2) + 1;
x4 = R_0.*cyl_d_4(:,1); %R = 1.5e-3
y4 = (rho_0*Ka).*cyl_d_4(:,2) + 1;
x5 = R_0.*cyl_d_5(:,1); %R = 3.0e-3
y5 = (rho_0*Ka).*cyl_d_5(:,2) + 1;
x6 = R_0.*cyl_d_6(:,1); %R = 7.0e-3
y6 = (rho_0*Ka).*cyl_d_6(:,2) + 1;
x7 = R_0.*cyl_d_7(:,1); %R = 0.02
y7 = (rho_0*Ka).*cyl_d_7(:,2) + 1;
x8 = R_0.*cyl_d_8(:,1); %R = 0.03
y8 = (rho_0*Ka).*cyl_d_8(:,2) + 1;

%plot(x1,y1)
%hold on
%plot(x2,y2)
%hold on
%plot(x3,y3)
%hold on
%plot(x4,y4)
%hold on
%plot(x5,y5)
%hold on
%plot(x6,y6)
%hold on
%plot(x7,y7)
%hold on
plot(x8,y8)
%hold on
title('Index of Refraction Functions')
xlabel('Radius')
ylabel('Index of Refraction')
%legend("t=1", "t=2", "t=3", "t=4", "t=5", "t=6", "t=7", "t=8")

