function [dn_dr] = dn_dr_30(r)
    dn_dr = -7.984e-8*r^3 + 2.8266e-6*r^2 - 2.96e-5*r + 9.478e-5;
end