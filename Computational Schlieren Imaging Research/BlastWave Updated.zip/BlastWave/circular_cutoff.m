function [intensity] = circular_cutoff(initial_rays, final_rays)
    disp_x = final_rays(:,:,1) - initial_rays(:,:,1);
    disp_y = final_rays(:,:,2) - initial_rays(:,:,2);
    max_disp_mag = 0;
    for rows = 1:length(disp_x(:,1))
        for cols = 1:length(disp_x(1,:))
            if sqrt(disp_x(rows,cols)^2 + disp_y(rows,cols)^2)>max_disp_mag
                max_disp_mag = sqrt(disp_x(rows,cols)^2 + disp_y(rows,cols)^2);
            end
        end
    end
    k = 0.7/max_disp_mag;
    rows = length(disp_x(:,1));
    cols = length(disp_x(1,:));
    intensity = ones(rows,cols);
    for rows = 1:length(intensity(:,1))
        for cols = 1:length(intensity(1,:))
            intensity(rows,cols) = 0.7 - sqrt(disp_x(rows,cols)^2 + disp_y(rows,cols)^2)*k;
        end
    end
end