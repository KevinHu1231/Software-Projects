function [plot_intensities] = New_Pixel_Array(start_x_step, start_y_step, start_positions, end_positions, ray_spread, p_size_f, b)
    start_x_lb = min(start_positions(:,1));
    start_x_hb = max(start_positions(:,1));
    start_y_lb = min(start_positions(:,2));
    start_y_hb = max(start_positions(:,2));
    
    len_x = start_x_hb - start_x_lb;
    len_y = start_y_hb - start_y_lb;
    
    step_size_x = start_x_step/p_size_f;
    step_size_y = start_y_step/p_size_f;
    
    end_x_lb = min(end_positions(:,1));
    end_x_hb = max(end_positions(:,1));
    end_y_lb = min(end_positions(:,2));
    end_y_hb = max(end_positions(:,2));
    
    original_start_x = start_x_lb - (step_size_x/2);
    original_start_y = start_y_lb - (step_size_y/2);
    original_end_x = start_x_hb + (step_size_x/2);
    original_end_y = start_y_hb + (step_size_y/2);
    
    degree_less_x = original_start_x - end_x_lb;
    degree_less_y = original_start_y - end_y_lb;
    degree_more_x = end_x_hb - original_end_x;
    degree_more_y = end_y_hb - original_end_y;
    
    num_less_x = 0;
    num_less_y = 0;
    num_more_x = 0;
    num_more_y = 0;
    
    if degree_less_x>=0
        num_less_x = floor(degree_less_x/step_size_x)+1;
    end
    if degree_more_x>=0
        num_more_x = floor(degree_more_x/step_size_x)+1;
    end
    if degree_less_y>=0
        num_less_y = floor(degree_less_y/step_size_y)+1;
    end
    if degree_more_y>=0
        num_more_y = floor(degree_more_y/step_size_y)+1;
    end
    
    actual_start_x = original_start_x - num_less_x*step_size_x;
    actual_end_x = original_end_x + num_more_x*step_size_x;
    actual_start_y = original_start_y - num_less_y*step_size_y;
    actual_end_y = original_end_y + num_more_y*step_size_y;
    
    num_buckets_x = (length(start_positions(:,1))*p_size_f - (p_size_f - 1)) + num_less_x + num_more_x; %change
    num_buckets_y = (length(start_positions(:,2))*p_size_f - (p_size_f - 1)) + num_less_y + num_more_y;
    
    positions = zeros(num_buckets_y, num_buckets_x, 2);
    intensities = zeros(num_buckets_y, num_buckets_x);
    norm_intensities = zeros(num_buckets_y,num_buckets_x);
    
    pos_one_x = actual_start_x + step_size_x/2;
    pos_one_y = actual_start_y + step_size_y/2;
    pos_last_x = pos_one_x + step_size_x*(num_buckets_x - 1);
    pos_last_y = pos_one_y + step_size_y*(num_buckets_y - 1);
    
    for i = 1:num_buckets_y
        for j = 1:num_buckets_x
            positions(i,j,1) = (pos_one_y + step_size_y*(i-1));
            positions(i,j,2) = (pos_one_x + step_size_x*(j-1));
        end
    end
    
    for i = 1:length(start_positions(:,1))
        low_ray_b_x = start_positions(i,1) - ray_spread;
        low_ray_b_y = start_positions(i,2) - ray_spread;
        high_ray_b_x = start_positions(i,1) + ray_spread;
        high_ray_b_y = start_positions(i,2) + ray_spread;
        
        if low_ray_b_x >= pos_one_x
            if mod((low_ray_b_x - pos_one_x),step_size_x) == 0
                low_bucket_x = (low_ray_b_x - pos_one_x)/step_size_x + 1;
            else
                rem_x = mod(low_ray_b_x - pos_one_x,step_size_x);
                low_ray_b_x = low_ray_b_x - rem_x;
                low_bucket_x = floor((low_ray_b_x - pos_one_x)/step_size_x) + 2;
            end
        else
            low_bucket_x = 1;
        end
        
        if low_ray_b_y >= pos_one_y
            if mod((low_ray_b_y - pos_one_y),step_size_y) == 0
                low_bucket_y = (low_ray_b_y - pos_one_y)/step_size_y + 1;
            else
                rem_y = mod(low_ray_b_y - pos_one_y,step_size_y);
                low_ray_b_y = low_ray_b_y - rem_y;
                low_bucket_y = floor((low_ray_b_y - pos_one_y)/step_size_y) + 2;
            end
        else
            low_bucket_y = 1;
        end
        
        if high_ray_b_x <= pos_last_x
            if mod((high_ray_b_x - pos_one_x),step_size_x) == 0
                high_bucket_x = (high_ray_b_x - pos_one_x)/step_size_x + 1;
            else
                rem_x = mod((high_ray_b_x - pos_one_x),step_size_x);
                high_ray_b_x = high_ray_b_x - rem_x;
                high_bucket_x = floor((high_ray_b_x - pos_one_x)/step_size_x) + 1;
            end
        else
            high_bucket_x = num_buckets_x;
        end
        
        if high_ray_b_y <= pos_last_y
            if mod((high_ray_b_y - pos_one_y),step_size_y) == 0
                high_bucket_y = (high_ray_b_y - pos_one_y)/step_size_y + 1;
            else
                rem_y = mod((high_ray_b_y - pos_one_y),step_size_y);
                high_ray_b_y = high_ray_b_y - rem_y;
                high_bucket_y = floor((high_ray_b_y - pos_one_y)/step_size_y) + 1;
            end
        else
            high_bucket_y = num_buckets_y;
        end
        
        for j = low_bucket:high_bucket
            diff = abs(plot_intensities(j,1)*b - start_positions(i,2));
            plot_norm_intensities(j,1) = plot_norm_intensities(j,1) + (1 - diff/ray_spread);
        end 
    end
    
    norm_constant = mean(plot_norm_intensities);
    
    for i = 1:length(end_positions(:,1))
        low_ray_b = end_positions(i,2) - ray_spread;
        high_ray_b = end_positions(i,2) + ray_spread;
        if low_ray_b >= pos_one
            if mod((low_ray_b - pos_one),step_size) == 0
                low_bucket = (low_ray_b - pos_one)/step_size + 1;
            else
                rem = mod(low_ray_b - pos_one,step_size);
                low_ray_b = low_ray_b - rem;
                low_bucket = floor((low_ray_b - pos_one)/step_size) + 2;
            end
        else
            low_bucket = 1;
        end
        
        if high_ray_b <= pos_last
            if mod((high_ray_b - pos_one),step_size) == 0
                high_bucket = (high_ray_b - pos_one)/step_size + 1;
            else
                rem = mod((high_ray_b - pos_one),step_size);
                high_ray_b = high_ray_b - rem;
                high_bucket = floor((high_ray_b - pos_one)/step_size) + 1;
            end
        else
            high_bucket = length(plot_intensities(:,1));
        end
        for j = low_bucket:high_bucket
            diff = abs(plot_intensities(j,1)*b - end_positions(i,2));
            plot_intensities(j,2) = plot_intensities(j,2) + (1 - diff/ray_spread);
        end   
    end
    
    p = plot_intensities;
    plot_intensities(:,2) = plot_intensities(:,2)./norm_constant;
    
     %   j = i %for interpolating intensity
     %   tf = 1;
     %   while tf == 1
     %       if j <= length(plot_intensities(:,1))
     %           diff = abs(plot_intensities(j,1)*b - end_positions(i,2))
     %           if diff <= ray_spread
     %               plot_intensities(j,2) = plot_intensities(j,2) + (1 - diff/ray_spread)
     %               j = j + 1;
     %           else
     %               tf = 0;
     %           end
     %       else
     %           tf = 0;
     %       end    
     %   end
     %   j = i-1
     %   tf = 1;
     %   while tf == 1
     %       if j >= 1
     %           diff = abs(plot_intensities(j,1)*b - end_positions(i,2))
     %           if diff <= ray_spread
     %               plot_intensities(j,2) = plot_intensities(j,2) + (1 - diff/ray_spread)
     %               j = j - 1;
     %           else
     %               tf = 0;
     %           end
     %       else
     %           tf = 0;
     %       end
     %   end
        %for constant intensities
        %check_boundary = (end_positions(i,2)-actual_start)/step_size;
        %if check_boundary == floor(check_boundary)
        %    bucket1 = floor(check_boundary);
        %    bucket2 = floor(check_boundary)+1;
        %    plot_intensities(bucket1,2) = plot_intensities(bucket1,2) + 0.5;
        %    plot_intensities(bucket2,2) = plot_intensities(bucket2,2) + 0.5;
        %    %add half intensities to both pixels
        %else
        %    bucket = floor(check_boundary)+1;
        %    plot_intensities(bucket,2) = plot_intensities(bucket,2) + 1;
        %end
end
