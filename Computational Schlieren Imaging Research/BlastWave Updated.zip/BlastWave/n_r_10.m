function [n] = n_r_10(r)
    n = 7.813e-6*r^2 - 3.551e-5*r + 1 + 2.2e-4;
end