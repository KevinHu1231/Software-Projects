load DensityRatio
load PressureRatio
load VelocityRatio
plot(DensityRatio(:,1),DensityRatio(:,2))
hold on
plot(PressureRatio(:,1),PressureRatio(:,2))
hold on
plot(VelocityRatio(:,1),VelocityRatio(:,2))

xlim([0 1.01])
ylim([-0.05 1.0])
title('Taylor Similarity')
xlabel('r/R_0')
legend("Density", "Pressure", "Velocity",'Location','northwest')