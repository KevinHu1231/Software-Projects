function [r_data, n_data] = data_selection(t)

    E_0 = 1;
    gamma = 1.4;
    b = 3.94;
    p_0 = 101325;
    a_0 = 344;
    R_0 = sqrt(4*E_0/(b*gamma*p_0));
    rho_0 = 1.2754;

    t_1 = 0.00163*R_0/a_0; %1.2676e-08
    t_2 = 0.00731*R_0/a_0; %5.6848e-08
    t_3 = 0.045*R_0/a_0; %3.4996e-07
    t_4 = 0.155*R_0/a_0; %1.2054e-06
    t_5 = 0.459*R_0/a_0; %3.5696e-06
    t_6 = 1.59*R_0/a_0; %1.2365e-06
    t_7 = 3.64*R_0/a_0; %2.8308e-05
    t_8 = 7.91*R_0/a_0; %6.1515e-05

    Ka = (0.226 * 1000/1000000);
    
    if t == 10
        load rho_t_10
        r_data = 0.9.*rho_t_10(:,1);
        n_data = (1.2*Ka).*rho_t_10(:,2) + 1;
    elseif t == 20
        load rho_t_20
        r_data = 0.9.*rho_t_20(:,1);
        n_data = (1.2*Ka).*rho_t_20(:,2) + 1;
    elseif t == 30
        load rho_t_30
        r_data = 0.9.*rho_t_30(:,1);
        n_data = (1.2*Ka).*rho_t_30(:,2) + 1;
    elseif t == 40
        load rho_t_40
        r_data = 0.9.*rho_t_40(:,1);
        n_data = (1.2*Ka).*rho_t_40(:,2) + 1;
    elseif t == 1
        load cyl_d_1
        r_data = R_0.*cyl_d_1(:,1);
        n_data = (rho_0*Ka).*cyl_d_1(:,2) + 1;
    elseif t == 2
        load cyl_d_2
        r_data = R_0.*cyl_d_2(:,1);
        n_data = (rho_0*Ka).*cyl_d_2(:,2) + 1;
    elseif t == 3
        load cyl_d_3
        r_data = R_0.*cyl_d_3(:,1);
        n_data = (rho_0*Ka).*cyl_d_3(:,2) + 1;
    elseif t == 4
        load cyl_d_4
        r_data = R_0.*cyl_d_4(:,1);
        n_data = (rho_0*Ka).*cyl_d_4(:,2) + 1;
    elseif t == 5
        load cyl_d_5
        r_data = R_0.*cyl_d_5(:,1);
        n_data = (rho_0*Ka).*cyl_d_5(:,2) + 1;
    elseif t == 6
        load cyl_d_6
        r_data = R_0.*cyl_d_6(:,1);
        n_data = (rho_0*Ka).*cyl_d_6(:,2) + 1;
    elseif t == 7
        load cyl_d_7
        r_data = R_0.*cyl_d_7(:,1);
        n_data = (rho_0*Ka).*cyl_d_7(:,2) + 1;
    elseif t == 8
        load cyl_d_8
        r_data = R_0.*cyl_d_8(:,1);
        n_data = (rho_0*Ka).*cyl_d_8(:,2) + 1;
    else
        r_data = [0 0 0];
        n_data = [0 0 0];
    end
end