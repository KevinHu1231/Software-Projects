load new_t_10
load new_t_20
load new_t_30
load new_t_40

plot(new_t_10(:,1),new_t_10(:,2))
hold on
plot(new_t_20(:,1),new_t_20(:,2))
hold on
plot(new_t_30(:,1),new_t_30(:,2))
hold on
plot(new_t_40(:,1),new_t_40(:,2))
hold on