function [intensity] = vertical_knife_edge(initial_rays, final_rays)
    disp_x = final_rays(:,:,1) - initial_rays(:,:,1);
    max_disp_mag = 0;
    for rows = 1:length(disp_x(:,1))
        for cols = 1:length(disp_x(1,:))
            if abs(disp_x(rows,cols))>max_disp_mag
                max_disp_mag = abs(disp_x(rows,cols));
            end
        end
    end
    k = 0.3/max_disp_mag;
    rows = length(disp_x(:,1));
    cols = length(disp_x(1,:));
    intensity = ones(rows,cols);
    for rows = 1:length(intensity(:,1))
        for cols = 1:length(intensity(1,:))
            intensity(rows,cols) = 0.7 - disp_x(rows,cols)*k;
        end
    end
end