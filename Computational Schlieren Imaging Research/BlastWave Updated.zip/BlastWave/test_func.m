xs = linspace(0,1e-4,1000); %25
%ns1 = ones(1,length(xs));
%ns2 = ones(1,length(xs));
%ns3 = ones(1,length(xs));
%ns4 = ones(1,length(xs));
%ns5 = ones(1,length(xs));
%ns6 = ones(1,length(xs));
ns7 = ones(1,length(xs));
for i = 1:length(xs)
    %ns1(i) = n_xyzt(10,xs(i),0,0);
    %ns2(i) = n_xyzt(20,xs(i),0,0);
    %ns3(i) = n_xyzt(30,xs(i),0,0);
    %ns4(i) = n_xyzt(40,xs(i),0,0);
    %ns5(i) = n_xyzt(101,xs(i),0,0);
    %ns6(i) = n_xyzt(201,xs(i),0,0);
    ns7(i) = n_xyzt(1,xs(i),0,0);
end
%plot(xs,ns1);
%hold on
%plot(xs,ns2);
%hold on
%plot(xs,ns3);
%hold on
%plot(xs,ns4);
%hold on
%plot(xs,ns5);
%hold on
%plot(xs,ns6);
%hold on
plot(xs,ns7);
hold on