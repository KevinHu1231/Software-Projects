function [n] = dn_dr_ts20(r)
    n = 8.826e-7*r^2 - 2.614e-5*r + 0.0002108;
end