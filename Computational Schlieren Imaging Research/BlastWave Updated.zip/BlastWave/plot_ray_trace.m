%Parameters to be changed
source_phi = 0;
source_theta = 0;
ray_pattern = 1;
num_rays = 30000;
source_x_length = 0;
source_y_length = 10;
source_center = [0,0,0];
x_hb = [1,10,10];
x_lb = [-1,-10,-1];
step_size = 0.01;
n_o = 1;
b = 6;
epsilon = 0.0001;
d_z = 3;
ray_spread = 0.05;
p_size_f = 10;
%Parameters to be changed

v_initial = [sin(source_phi)*cos(source_theta),sin(source_theta),cos(source_phi)*cos(source_theta)];
starting_rays = set_rays_pattern(ray_pattern,num_rays,source_x_length,source_y_length,source_center);
ending_rays = ones(num_rays,3);

for i = 1:num_rays
    x_initial = starting_rays(i,:);
    [v_path, x_path] = new_ray_trace(v_initial,x_initial,x_hb,x_lb,step_size,n_o,b,epsilon,d_z);
    endpoint = x_path(length(x_path),:);
    ending_rays(i,:) = endpoint;
end

data_points = New_Pixel_Array(starting_rays, ending_rays, ray_spread, p_size_f, b);
load RayTracingBenchmark
plot(RayTracingBenchmark(:,1),RayTracingBenchmark(:,2),'g')
hold on
plot(data_points(:,2),data_points(:,1),'b')
title('Ray Tracing Benchmark')
xlabel('I/Io')
ylabel('y/b')
ylim([-0.8,0.8])
legend("Benchmark", "30000 rays")