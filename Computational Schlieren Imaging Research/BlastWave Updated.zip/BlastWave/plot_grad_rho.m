function [rs,grad_rs] = plot_grad_rho(r_data,rho_data,lower_r,upper_r,num_entries)
    rs = linspace(lower_r,upper_r,num_entries);
    grad_rs = ones(1,length(rs));
    for i = 1:length(grad_rs)
        if rs(i)<r_data(1)
            r2 = r_data(2);
            r1 = r_data(1);
            n2 = rho_data(2);
            n1 = rho_data(1);
        elseif rs(i)>r_data(length(r_data))
            r2 = r_data(length(r_data));
            r1 = r_data(length(r_data)-1);
            n2 = rho_data(length(rho_data));
            n1 = rho_data(length(rho_data)-1);
        else
            for j = 1:length(r_data)
                if r_data(j)>=rs(i)
                    r2 = r_data(j);
                    r1 = r_data(j-1);
                    n2 = rho_data(j);
                    n1 = rho_data(j-1);
                    break
                end
            end
        end
        grad_rs(i) = (n2-n1)/(r2-r1);
    end
end