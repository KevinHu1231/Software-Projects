function[v_all,x_all] = new_ray_trace(v1,x1,x_hb,x_lb,step_size,r_data,n_data,type) 
    iter = 1;
    x = x1;
    v = v1;
    while 1
        x_new = x(iter,:)+step_size.*v(iter,:)./n_r_numerical(type,r_data,n_data,x(iter,1),x(iter,2),x(iter,3));
        if (x_lb(1) >= x_new(1))||(x_lb(2) >= x_new(2))||(x_lb(3) >= x_new(3))
            x = [x;x_new];
            v_new = v(iter,:)+step_size.*grad_n_r_numerical(type,r_data,n_data,x(iter,1),x(iter,2),x(iter,3));
            v = [v;v_new];
            break
        end
        if (x_hb(1) <= x_new(1))||(x_hb(2) <= x_new(2))||(x_hb(3) <= x_new(3))
            if (x_hb(3) <= x_new(3))
                v_propagate = v(length(v),:);
                theta = asin(v_propagate(2));
                phi = atan(v_propagate(1)/v_propagate(3));
                d = sqrt((x_hb(3)-x(length(x),3))^2/(1-phi^2-theta^2));
                [new_x,new_v] = propagate(1,d,0,0,0,x(length(x),:),v_propagate,x_hb(3));
                x = [x;new_x];
                v = [v;new_v];
                break
            else
                x = [x;x_new];
                v_new = v(iter,:)+step_size.*grad_n_r_numerical(type,r_data,n_data,x(iter,1),x(iter,2),x(iter,3));
                v = [v;v_new];
                break
            end
        end
        x = [x;x_new];
        v_new = v(iter,:)+step_size.*grad_n_r_numerical(type,r_data,n_data,x(iter,1),x(iter,2),x(iter,3));
        v = [v;v_new];
        iter = iter + 1;
    end
    x_all = x;
    v_all = v;
end