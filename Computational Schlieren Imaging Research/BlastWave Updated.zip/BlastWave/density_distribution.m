function [rho_r] = rho_x_y_t(t,x,y)
    R0_t10 = 7.47;
    R0_t20 = 11.565;
    R0_t30 = 15.345;
    R0_t40 = 19.08;
    
    if t==10
        R_0 = R0_t10;
    elseif t==20
        R_0 = R0_t20;
    elseif t==30
        R_0 = R0_t30;
    elseif t==40
        R_0 = R0_t40;
    else
        rho_r = 1;
    end
    
    r = x^2+y^2
end