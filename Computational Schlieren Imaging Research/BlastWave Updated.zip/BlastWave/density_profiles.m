load new_t_10
load new_t_20
load new_t_30
load new_t_40
load DensityRatio
load PressureRatio
load VelocityRatio
load t_10_data
load t_20_data
E = 1.38;
p_o = 101.325;%assume atmospheric pressure
R_star = (E/p_o)^(1/3);
rho_0 = 
plot(new_t_10(:,1).*(0.9/7.47),new_t_10(:,2))%.*(0.9/7.47)
hold on
plot(new_t_20(:,1).*(0.9/11.565),new_t_20(:,2))%.*(0.9/11.565)
hold on
plot(new_t_30(:,1).*(0.9/15.345),new_t_30(:,2))%.*(0.9/15.345)
hold on
plot(new_t_40(:,1).*(0.9/19.08),new_t_40(:,2))%.*(0.9/19.08)
hold on
plot(t10_data(:,1).*(R_star/116.5),t10_data(:,2))%R_0 = 116.5 %R = r/R*
%r = R*R*
%r/R_0 = R*R*/R_0
hold on
plot(t20_data(:,1).*(R_star/202),t20_data(:,2))
hold on
%plot(DensityRatio(:,1),DensityRatio(:,2))
%hold on
%plot(PressureRatio(:,1),PressureRatio(:,2))
%hold on
%plot(VelocityRatio(:,1),VelocityRatio(:,2))

xlim([0 1.0])
%xlim([0 25])
ylim([-0.05 2.2])
title('Density Profiles')
xlabel('r/R_0')
ylabel('rho/rho_0')
legend("Time = 10 us", "Time = 20 us", "Time = 30 us", "Time = 40 us", "Taylor Sim t = 10 us", "Taylor Sim t = 20 us", 'Location','northwest')
