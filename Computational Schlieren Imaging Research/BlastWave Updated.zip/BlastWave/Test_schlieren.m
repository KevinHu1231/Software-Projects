%Parameters to be changed
source_phi = 0;
source_theta = 0;
ray_pattern = 2;
num_rays = 512*512;
num_rays_x = 512;
num_rays_y = 512;
source_x_length = 20;
source_y_length = 20;
source_center = [0,0,-10];
x_hb = [11,11,10];
x_lb = [-11,-11,-11];
step_size = 0.01;
t = 10;

%Parameters can be used for intensity distribution
ray_spread = 0.05;
p_size_f = 10;
%Parameters to be changed

v_initial = [sin(source_phi)*cos(source_theta),sin(source_theta),cos(source_phi)*cos(source_theta)];
starting_rays = set_rays_pattern(ray_pattern,num_rays,source_x_length,source_y_length,source_center);
ending_rays = ones(num_rays_x,num_rays_y,3);
x_initial = [starting_rays(1,1,1),starting_rays(1,1,2),starting_rays(1,1,3)];

[v_path, x_path] = new_ray_trace(v_initial,x_initial,x_hb,x_lb,step_size,t);


