E = 112e-3;
t = linspace(0,50e-6,101);
p_s = zeros(1,101);
for i = 1:length(t)
    p_s(i) = 0.155 * E * R_0(t(i))^(-3);
end
plot(t,p_s);
title('Pressure At Blast Wave Front as a Function of Time')
xlabel('Time (s)')
ylabel('Pressure (kPa)')

