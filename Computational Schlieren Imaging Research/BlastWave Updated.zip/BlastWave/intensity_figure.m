load intensity_data_t1
load intensity_data_t2
load intensity_data_t3
load intensity_data_t4
load intensity_data_t10
load intensity_data_t20
load intensity_data_t30
load intensity_data_t40

load intensity_data_t1_old
load intensity_data_t2_old
load intensity_data_t3_old
load intensity_data_t4_old
load intensity_data_t10_old
load intensity_data_t20_old
load intensity_data_t30_old
load intensity_data_t40_old

load intensity_data_cyl
load intensity_data_sph

load rho_t_10
load rho_t_20
load rho_t_30
load rho_t_40
load cyl_d_1
load cyl_d_2
load cyl_d_3
load cyl_d_4
load cyl_d_5
load cyl_d_6
load cyl_d_7
load cyl_d_8

E_0 = 1;
gamma = 1.4;
b = 3.94;
p_0 = 101325;
a_0 = 344;
R_0 = sqrt(4*E_0/(b*gamma*p_0));
rho_0 = 1.2754;

x1 = R_0.*cyl_d_1(:,1); %R = 1.5e-4
y1 = rho_0.*cyl_d_1(:,2);
x2 = R_0.*cyl_d_2(:,1); %R = 3.0e-4
y2 = rho_0.*cyl_d_2(:,2);
x3 = R_0.*cyl_d_3(:,1); %R = 7.0e-4
y3 = rho_0.*cyl_d_3(:,2);
x4 = R_0.*cyl_d_4(:,1); %R = 1.5e-3
y4 = rho_0.*cyl_d_4(:,2);
x5 = R_0.*cyl_d_5(:,1); %R = 3.0e-3
y5 = rho_0.*cyl_d_5(:,2);
x6 = R_0.*cyl_d_6(:,1); %R = 7.0e-3
y6 = rho_0.*cyl_d_6(:,2);
x7 = R_0.*cyl_d_7(:,1); %R = 0.02
y7 = rho_0.*cyl_d_7(:,2);
x8 = R_0.*cyl_d_8(:,1); %R = 0.03
y8 = rho_0.*cyl_d_8(:,2);

x10 = 0.9.*rho_t_10(:,1);
y10 = 1.2.*rho_t_10(:,2);
x20 = 0.9.*rho_t_20(:,1);
y20 = 1.2.*rho_t_20(:,2);
x30 = 0.9.*rho_t_30(:,1);
y30 = 1.2.*rho_t_30(:,2);
x40 = 0.9.*rho_t_40(:,1);
y40 = 1.2.*rho_t_40(:,2);

n = 1000;
l = 0;

[x_plot,y_plot] = plot_grad_rho(x1,y1,l,1.5e-4,n); %maxx = 1.5e-4, maxy = 8.2554e5, minx = 0, miny = -7.4291e6
%[x_plot,y_plot] = plot_grad_rho(x2,y2,l,3.0e-4,n); %maxx = 3.0e-4, maxy = 2.5976e5, minx = 0, miny = -1.5779e6
%[x_plot,y_plot] = plot_grad_rho(x3,y3,l,7.0e-4,n); %maxx = 7.0e-4, maxy = 3.0917e4, minx = 0, miny = -7.4944e5
%[x_plot,y_plot] = plot_grad_rho(x4,y4,l,1.5e-3,n); %maxx = 0.0015, maxy = 5.4949e3, minx = 0, miny = -1.5524e5
%[x_plot,y_plot] = plot_grad_rho(x5,y5,l,3.0e-3,n); %maxx = 0.0030, maxy = 2.0613e3, minx = 0, miny = -2.7098e4
%[x_plot,y_plot] = plot_grad_rho(x6,y6,l,7.0e-3,n); %maxx = 0.0070, maxy = 4.2438e3, minx = 0, miny = -4.0648e3
%[x_plot,y_plot] = plot_grad_rho(x7,y7,l,0.02,n); %maxx = 0.0200, maxy = 4.8351e3, minx = 0, miny = -667.2289
%[x_plot,y_plot] = plot_grad_rho(x8,y8,l,0.03,n); %maxx = 0.0300, maxy = 1.5850e4, minx = 0, miny = -91.2368

%[x_plot,y_plot] = plot_grad_rho(x10,y10,l,20,n); %maxx = 20, maxy = 0.6647, minx = 0, miny = -2.5671
%[x_plot,y_plot] = plot_grad_rho(x20,y20,l,20,n); %maxx = 20, maxy = 0.1266, minx = 0, miny = -0.6130
%[x_plot,y_plot] = plot_grad_rho(x30,y30,l,20,n); %maxx = 20, maxy = 0.0853, minx = 0, miny = -0.8341
%[x_plot,y_plot] = plot_grad_rho(x40,y40,l,20,n); %maxx = 25, maxy = 0.0530, minx = 0, miny = -0.3739

max_x = max(x_plot);
max_y = max(y_plot);
min_x = min(x_plot);
min_y = min(y_plot);

plot(x_plot,y_plot)
hold on
title('Gradient of Rho as a Function of R')
xlabel('Radius')
ylabel('Gradient of Rho')

x1 = intensity_data_t1_old(:,1);
x1 = 0 + (x1 - min(x1))*(1.5e-4-0)/max(x1);
x2 = intensity_data_t2_old(:,1);
x2 = 0 + (x2 - min(x2))*(3.0e-4-0)/max(x2);
x3 = intensity_data_t3_old(:,1);
x3 = 0 + (x3 - min(x3))*(7.0e-4-0)/max(x3);
x4 = intensity_data_t4_old(:,1);
x4 = 0 + (x4 - min(x4))*(0.0015-0)/max(x4);
x5 = intensity_data_t10_old(:,1);
x5 = 0 + (x5 - min(x5))*(20-0)/max(x5);
x6 = intensity_data_t20_old(:,1);
x6 = 0 + (x6 - min(x6))*(20-0)/max(x6);
x7 = intensity_data_t30_old(:,1);
x7 = 0 + (x7 - min(x7))*(20-0)/max(x7);
x8 = intensity_data_t40_old(:,1);
x8 = 0 + (x8 - min(x8))*(20-0)/max(x8);

y1 = intensity_data_t1_old(:,2);
y1 = min_y + (y1 - min(y1))*(max_y-min_y)/max(y1);
y2 = intensity_data_t2_old(:,2);
y2 = min_y + (y2 - min(y2))*(max_y-min_y)/max(y2);
y3 = intensity_data_t3_old(:,2);
y3 = min_y + (y3 - min(y3))*(max_y-min_y)/max(y3);
y4 = intensity_data_t4_old(:,2);
y4 = min_y + (y4 - min(y4))*(max_y-min_y)/max(y4);
y5 = intensity_data_t10_old(:,2);
y5 = min_y + (y5 - min(y5))*(max_y-min_y)/max(y5);
y6 = intensity_data_t20_old(:,2);
y6 = min_y + (y6 - min(y6))*(max_y-min_y)/max(y6);
y7 = intensity_data_t30_old(:,2);
y7 = min_y + (y7 - min(y7))*(max_y-min_y)/max(y7);
y8 = intensity_data_t40_old(:,2);
y8 = min_y + (y8 - min(y8))*(max_y-min_y)/max(y8);

plot(x1,y1)
hold on

x1 = intensity_data_cyl(:,1);
x1 = 0 + (x1 - min(x1))*(1.5e-4-0)/max(x1);
x2 = intensity_data_cyl(:,1);
x2 = 0 + (x2 - min(x2))*(3.0e-4-0)/max(x2);
x3 = intensity_data_cyl(:,1);
x3 = 0 + (x3 - min(x3))*(7.0e-4-0)/max(x3);
x4 = intensity_data_cyl(:,1);
x4 = 0 + (x4 - min(x4))*(0.0015-0)/max(x4);
x5 = intensity_data_sph(:,1);
x5 = 0 + (x5 - min(x5))*(20-0)/max(x5);
x6 = intensity_data_sph(:,1);
x6 = 0 + (x6 - min(x6))*(20-0)/max(x6);
x7 = intensity_data_sph(:,1);
x7 = 0 + (x7 - min(x7))*(20-0)/max(x7);
x8 = intensity_data_sph(:,1);
x8 = 0 + (x8 - min(x8))*(20-0)/max(x8);

y1 = intensity_data_cyl(:,2);
y1 = min_y + (y1 - min(y1))*(max_y-min_y)/max(y1);
y2 = intensity_data_cyl(:,2);
y2 = min_y + (y2 - min(y2))*(max_y-min_y)/max(y2);
y3 = intensity_data_cyl(:,2);
y3 = min_y + (y3 - min(y3))*(max_y-min_y)/max(y3);
y4 = intensity_data_cyl(:,2);
y4 = min_y + (y4 - min(y4))*(max_y-min_y)/max(y4);
y5 = intensity_data_sph(:,2);
y5 = min_y + (y5 - min(y5))*(max_y-min_y)/max(y5);
y6 = intensity_data_sph(:,2);
y6 = min_y + (y6 - min(y6))*(max_y-min_y)/max(y6);
y7 = intensity_data_sph(:,2);
y7 = min_y + (y7 - min(y7))*(max_y-min_y)/max(y7);
y8 = intensity_data_sph(:,2);
y8 = min_y + (y8 - min(y8))*(max_y-min_y)/max(y8);

plot(x1,y1)
hold on

legend("Gradient of Rho","Synthetic Intensity","Experimental Intensity", "Location", "Southwest")
