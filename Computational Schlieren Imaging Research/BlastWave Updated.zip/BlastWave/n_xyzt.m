function [n_r] = n_xyzt(t,x,y,z)
    
    R0_t10 = 7.47;
    R0_t20 = 11.565;
    R0_t30 = 15.345;
    R0_t40 = 19.08;
    R0_t10_ts = 11.4;
    R0_t20_ts = 19.95;
    
    R0_t1_c = 5.1451e-5;
    
    R_vac_ts10 = 5.4993;
    R_vac_ts20 = 7.1529;
    
    R_vac_t1_c = 2.3614e-5;
    
    rho_0 = 1.2;
    Ka = (0.226 * 1000/1000000);
    
    
    r = sqrt(x^2+y^2+z^2);
    
    if t==10
        R_0 = R0_t10;
        R_vac = -1;
    elseif t==20
        R_0 = R0_t20;
        R_vac = -1;
    elseif t==30
        R_0 = R0_t30;
        R_vac = -1;
    elseif t==40
        R_0 = R0_t40;
        R_vac = -1;
    elseif t==101
        R_0 = R0_t10_ts;
        R_vac = R_vac_ts10;
    elseif t==201
        R_0 = R0_t20_ts;
        R_vac = R_vac_ts20;
    elseif t==1
        R_0 = R0_t1_c;
        R_vac = R_vac_t1_c;
    else
        n_r = rho_0*Ka + 1;
    end
    
    if r>=R_0
        n_r = rho_0*Ka + 1;
    elseif r<=R_vac
        n_r = 1.000001;
    else
        if t==10
            n_r = n_r_10(r);
        elseif t==20
            n_r = n_r_20(r);
        elseif t==30
            n_r = n_r_30(r);
        elseif t==40
            n_r = n_r_40(r);
        elseif t==101
            n_r = n_r_ts10(r);
        elseif t==201
            n_r = n_r_ts20(r);
        elseif t==1
            n_r = n_r_c1(r);  
        else
            n_r = rho_0*Ka + 1;
        end
    end