function [dn_dr] = dn_dr_10(r)
    dn_dr = 1.5626e-5*r - 3.551e-5;
end