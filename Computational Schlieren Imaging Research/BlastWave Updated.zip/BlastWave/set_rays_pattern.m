function [rays] = set_rays_pattern(num,num_rays,x_length,y_length,center)%finalized
    if num == 1 %1D arrangement of rays
        if x_length == 0
            d_between_rays = y_length / (num_rays - 1);
            start_ray = center - [0, y_length/2, 0];
            rays = ones(num_rays,3);
            rays(1,:) = start_ray;
            for i = 1:(num_rays - 1)
               rays(i+1,:)=rays(i,:)+[0,d_between_rays,0];
            end
        elseif y_length == 0
            d_between_rays = x_length / (num_rays - 1);
            start_ray = center - [x_length/2, 0, 0];
            rays = ones(num_rays,3);
            rays(1,:) = start_ray;
            for i = 1:(num_rays - 1)
               rays(i+1,:)=rays(i,:)+[d_between_rays,0,0];
            end
        else
            rays = [0];
        end       
    else%2D arrangement of rays
        if x_length == y_length
            rays_on_side = round(sqrt(num_rays));
            new_num_rays = rays_on_side^2;
            d_between_rays = x_length / (rays_on_side - 1);
            start_ray = center - [x_length/2, y_length/2, 0];
            rays = ones(rays_on_side,rays_on_side,3);
            rays(1,1,:) = start_ray;
            %i = 1;
            %j = 1;
            for i = 1:rays_on_side
                for j = 1:rays_on_side
       
                    if i==1 & j==1
                    else
                        if j==1
                            rays(i,j,:)=[rays((i-1),j,1),rays((i-1),j,2),rays((i-1),j,3)]+[d_between_rays,0,0];
                            %j = j+1;
                        else
                            rays(i,j,:)=[rays(i,(j-1),1),rays(i,(j-1),2),rays(i,(j-1),3)]+[0,d_between_rays,0];
                            %j = j+1;
                        end
                    end
                end
            end
        else
            %This is for x_length != y_length which is more difficult
            %implementation, may finish another time
            rays = [0];
        end
    end