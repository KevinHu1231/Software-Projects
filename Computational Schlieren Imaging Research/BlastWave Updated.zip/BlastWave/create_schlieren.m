%Parameters not to be changed
source_phi = 0;
source_theta = 0;
ray_pattern = 2;
num_rays = 512*512;
num_rays_x = 512;
num_rays_y = 512;

%Parameters to be changed

% Typical Image Sizes used:

% 20,30,40,50 for spherical blasts t = 10,20,30,40 respectively.
% 3.0e-4,6.0e-4,1.4e-3,3.0e-3,6.0e-3,0.014,0.04,0.06 for cylindrical blasts
% t = 1,2,3,4,5,6,7,8 respectively

source_x_length = 3.0e-3; %X and Y length of the image window/size, should be the same
source_y_length = 3.0e-3;
source_center = [0,0,-1.5e-3]; %First two numbers stay at zero, last number should be negative half the length of the image window
x_hb = [1.6e-3,1.6e-3,1.5e-3]; %Higher bounds for ray tracing, first two numbers should be one significant digit higher than the last which is half the length of the image window
x_lb = [-1.6e-3,-1.6e-3,-1.6e-3]; %Lower bounds for ray tracing, all three numbers should be one significant digit higher than half the length of the image window
size = 3.0e-3; %Length of the image window
step_size = size/1000; %Step size for ray tracing, ray tracing set for ~1000 steps

t = 4; % Used To Select Data, t = 10,20,30,40 for spherical blast data, t = 1,2,3,4,5,6,7,8 for cylindrical blast data

type = 2; % Type 1: Spherical Blast Wave; Type 2: Cylindrical Blast Wave

%%%Code not to be changed%%%

[r_data, n_data] = data_selection(t); %Select density/IOR data from files

v_initial = [sin(source_phi)*cos(source_theta),sin(source_theta),cos(source_phi)*cos(source_theta)]; %Set initial direction
starting_rays = set_rays_pattern(ray_pattern,num_rays,source_x_length,source_y_length,source_center); %Initialize Rays
ending_rays = ones(num_rays_x,num_rays_y,3);

%%%Ray Trace Rays%%%
for i = 1:num_rays_x
    for j = 1:num_rays_y
        x_initial = [starting_rays(i,j,1),starting_rays(i,j,2),starting_rays(i,j,3)];
        [v_path, x_path] = new_ray_trace(v_initial,x_initial,x_hb,x_lb,step_size,r_data,n_data,type);
        endpoint = x_path(length(x_path),:);
        ending_rays(i,j,:) = endpoint;
    end
end

intensity_matrix = circular_cutoff(starting_rays,ending_rays); %Function can be changed to change the applied knife edge, function name can be changed to horizontal_knife_edge, vertical_knife_edge, circular_cutoff, inv_circular_cutoff

imwrite(intensity_matrix,'myimage.png') ; 
figure
imshow(intensity_matrix)
figure
imshow(imread('myimage.png'))