E_0 = 1;
gamma = 1.4;
b = 3.94;
p_0 = 101325;
a_0 = 344;
R_0 = sqrt(4*E_0/(b*gamma*p_0));
rho_0 = 1.2754;

%plot(0.9.*rho_t_10(:,1),1.2.*rho_t_10(:,2))
%plot(0.9.*rho_t_20(:,1),1.2.*rho_t_20(:,2))
%plot(0.9.*rho_t_30(:,1),1.2.*rho_t_30(:,2))
%plot(0.9.*rho_t_40(:,1),1.2.*rho_t_40(:,2))

%plot(R_0.*cyl_d_1(:,1),rho_0.*cyl_d_1(:,2))
%plot(R_0.*cyl_d_2(:,1),rho_0.*cyl_d_2(:,2))
%plot(R_0.*cyl_d_3(:,1),rho_0.*cyl_d_3(:,2))
%plot(R_0.*cyl_d_4(:,1),rho_0.*cyl_d_4(:,2))
%plot(R_0.*cyl_d_5(:,1),rho_0.*cyl_d_5(:,2))
%plot(R_0.*cyl_d_6(:,1),rho_0.*cyl_d_6(:,2))
%plot(R_0.*cyl_d_7(:,1),rho_0.*cyl_d_7(:,2))
%plot(R_0.*cyl_d_8(:,1),rho_0.*cyl_d_8(:,2))

title('Rho as a Function of R')
xlabel('Radius')
ylabel('Rho')