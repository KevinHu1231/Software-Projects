load rho_t_10
load rho_t_20
load rho_t_30
load rho_t_40
load ts_10
load ts_20

E = 1.38;
p_o = 101325;%assume atmospheric pressure
R_star = (E/p_o)^(1/3);
rho_0 = 1.225;

Ka = (0.226 * 1000/1000000);
x10 = 0.9.*rho_t_10(:,1);
y10 = (1.2*Ka).*rho_t_10(:,2) + 1;
x20 = 0.9.*rho_t_20(:,1);
y20 = (1.2*Ka).*rho_t_20(:,2) + 1;
x30 = 0.9.*rho_t_30(:,1);
y30 = (1.2*Ka).*rho_t_30(:,2) + 1;
x40 = 0.9.*rho_t_40(:,1);
y40 = (1.2*Ka).*rho_t_40(:,2) + 1;
xts10 = R_star.*ts_10(:,1);
yts10 = (1.225*Ka).*ts_10(:,2) + 1;
xts20 = R_star.*ts_20(:,1);
yts20 = (1.225*Ka).*ts_20(:,2) + 1;


plot(x10,y10)
hold on
plot(x20,y20)
hold on
plot(x30,y30)
hold on
plot(x40,y40)
hold on
plot(xts10,yts10)
hold on
plot(xts20,yts20)
hold on
title('Index of Refraction Functions')
xlabel('Radius')
ylabel('Index of Refraction')
legend("t=10", "t=20", "t=30", "t=40")