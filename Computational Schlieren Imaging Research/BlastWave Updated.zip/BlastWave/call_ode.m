%function [E,Y] = call_ode()
 %   espan = [0 3000];
  %  y1_0 = 8;
   % y2_0 = 5;
    %y3_0 = 2;
    %[E,Y] = ode45(@ODE_Solver,espan,[y1_0 y2_0 y3_0]);
    %plot(E,Y(:,1),"o")
%end
function [T,Y] = call_ode()
 tspan = [0 3000];
 y1_0 = 2;
 y2_0 = 1;
 y3_0 = 1;
 [T,Y] = ode45(@ODE_Solver,tspan,[y1_0 y2_0 y3_0]);
 plot(T,Y(:,1),'o')
end