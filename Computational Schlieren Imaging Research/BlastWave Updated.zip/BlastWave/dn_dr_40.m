function [dn_dr] = dn_dr_40(r)
    dn_dr = -1.7584e-8*r^3 + 8.703e-7*r^2 - 1.202e-5*r + 4.838e-5;
end