function [n] = dn_dr_ts10(r)
    n = 2.296e-5*r - 9.35e-5;
end