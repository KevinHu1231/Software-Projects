function [intensity] = horizontal_knife_edge(initial_rays, final_rays)
    disp_y = final_rays(:,:,2) - initial_rays(:,:,2);
    max_disp_mag = 0;
    for rows = 1:length(disp_y(:,1))
        for cols = 1:length(disp_y(1,:))
            if abs(disp_y(rows,cols))>max_disp_mag
                max_disp_mag = abs(disp_y(rows,cols));
            end
        end
    end
    k = 0.5/max_disp_mag;
    rows = length(disp_y(:,1));
    cols = length(disp_y(1,:));
    intensity = ones(rows,cols);
    for rows = 1:length(intensity(:,1))
        for cols = 1:length(intensity(1,:))
            intensity(rows,cols) = 0.5 - disp_y(rows,cols)*k;
        end
    end
end