function [grad_n] = grad_n_r_numerical(type,r_data,n_data,x,y,z)
    if type == 1
        r = sqrt(x^2+y^2+z^2);
    elseif type == 2
        r = sqrt(x^2+y^2);
    else
        r = sqrt(x^2+y^2+z^2);
    end
    
    if r<r_data(1)
        r2 = r_data(2);
        r1 = r_data(1);
        n2 = n_data(2);
        n1 = n_data(1);
    elseif r>r_data(length(r_data))
        r2 = r_data(length(r_data));
        r1 = r_data(length(r_data)-1);
        n2 = n_data(length(n_data));
        n1 = n_data(length(n_data)-1);
    else
        for i = 1:length(r_data)
            if r_data(i)>=r
                r2 = r_data(i);
                r1 = r_data(i-1);
                n2 = n_data(i);
                n1 = n_data(i-1);
                break
            end
        end
    end
    dn_dr = (n2-n1)/(r2-r1);
    if type == 1
        grad_n = [x*(x^2+y^2+z^2)^(-1/2)*dn_dr, y*(x^2+y^2+z^2)^(-1/2)*dn_dr, z*(x^2+y^2+z^2)^(-1/2)*dn_dr];
    elseif type == 2
        grad_n = [x*(x^2+y^2)^(-1/2)*dn_dr, y*(x^2+y^2)^(-1/2)*dn_dr, 0];
    else
        grad_n = [x*(x^2+y^2+z^2)^(-1/2)*dn_dr, y*(x^2+y^2+z^2)^(-1/2)*dn_dr, z*(x^2+y^2+z^2)^(-1/2)*dn_dr];
    end
end