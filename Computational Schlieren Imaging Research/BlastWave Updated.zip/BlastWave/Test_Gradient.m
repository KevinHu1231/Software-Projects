[r_data, n_data] = data_selection(1);%1.5e-4
test_coords = [0.5e-4,0.6e-4,0];
grad_n = grad_n_r_numerical(2,r_data,n_data,test_coords(1),test_coords(2),test_coords(3))